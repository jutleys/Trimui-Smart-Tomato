#include <stdio.h>
#include <unistd.h>
#include <stdint.h>
#include <string.h>
#include <fcntl.h>
#include <pthread.h>
#include <sys/mman.h>
#include <linux/fb.h>
#include <linux/input.h>
#include <linux/rtc.h>

//	Button Defines
#define BUTTON_UP	KEY_UP
#define BUTTON_DOWN	KEY_DOWN
#define BUTTON_LEFT	KEY_LEFT
#define BUTTON_RIGHT	KEY_RIGHT
#define BUTTON_A	KEY_SPACE
#define BUTTON_B	KEY_LEFTCTRL
#define BUTTON_X	KEY_LEFTSHIFT
#define BUTTON_Y	KEY_LEFTALT
#define	BUTTON_L	KEY_TAB
#define	BUTTON_R	KEY_BACKSPACE
#define	BUTTON_SELECT	KEY_RIGHTCTRL
#define	BUTTON_START	KEY_ENTER
#define	BUTTON_MENU	KEY_ESC

//	for ev.value
#define RELEASED	0
#define PRESSED		1
#define REPEAT		2

//	for clock
#define	CHR_WIDTH	(3 * 4 + 4)
#define	CHR_HEIGHT	(5 * 4)
#define	DISPLAY_WIDTH	(CHR_WIDTH * 19 + 8)
#define	DISPLAY_HEIGHT	(CHR_HEIGHT + 8)
enum { YEAR, MON, DAY, HOUR, MIN, SEC };

//	Global Variables
struct	tm		clk;
pthread_t		clock_pt;
pthread_mutex_t		clock_mx;
uint16_t		*fbofs;
uint32_t		focus = HOUR;

//
//	Read Clock (system)
//
void read_clock(void) {
	struct timeval tod;
	gettimeofday(&tod, NULL);
	gmtime_r(&tod.tv_sec, &clk);
}

//
//	Read Clock (RTC)
//
void read_clock_rtc(void) {
	int cfd = open("/dev/rtc0", O_RDONLY);
	if (cfd > 0) {
		ioctl(cfd, RTC_RD_TIME, &clk);
		close(cfd);
	} else	read_clock();
}

//
//	Write Clock (system)
//
void write_clock(void) {
	struct timeval tod;
	gettimeofday(&tod, NULL);
	tod.tv_sec = mktime(&clk);
	settimeofday(&tod, NULL);
}

//
//	Write Clock (RTC & system)
//
void write_clock_rtc(void) {
	int cfd = open("/dev/rtc0", O_WRONLY);
	if (cfd > 0) { ioctl(cfd, RTC_SET_TIME, &clk); close(cfd); }
	write_clock();
}

//
//	Initialize Clock
//
void init_clock(void) {
	read_clock();
	write_clock_rtc();
	FILE* fp = fopen("clock.txt", "r");
	if (fp) {
		time_t now = mktime(&clk);
		fscanf(fp, "%04u/%02u/%02u %02u:%02u:%02u",
			&clk.tm_year, &clk.tm_mon, &clk.tm_mday, &clk.tm_hour, &clk.tm_min, &clk.tm_sec);
		fclose(fp);
		clk.tm_year -= 1900; clk.tm_mon--;
		if ( now < mktime(&clk) ) write_clock_rtc();
	}
}

//
//	Write clock.txt
//
void write_clockfile(void) {
	FILE* fp = fopen("clock.txt", "w");
	if (fp) {
		fprintf(fp, "%04u/%02u/%02u %02u:%02u:%02u",
			clk.tm_year+1900, clk.tm_mon+1, clk.tm_mday, clk.tm_hour, clk.tm_min, clk.tm_sec);
		fflush(fp);
		fsync(fileno(fp));
		fclose(fp);
	}
}

//
//	Print Number (rotate90 240x320)
//
void print_num(uint8_t num, uint32_t x, uint32_t color) {
	const uint16_t pix[13] = {
		0b000000000000000,	// space
		0b000001010100000,	// /
		0b111101101101111,	// 0
		0b001001001001001,	// 1
		0b111001111100111,	// 2
		0b111001111001111,	// 3
		0b101101111001001,	// 4
		0b111100111001111,	// 5
		0b111100111101111,	// 6
		0b111001001001001,	// 7
		0b111101111101111,	// 8
		0b111101111001111,	// 9
		0b000010000010000 };	// :
	uint32_t	i, y;
	uint16_t	numpix, c16;
	uint16_t	*ofs, *ofs16;

	if ( num == ' ' ) num = 0; else num -= 0x2e;
	if ( ( num > 12 ) || ( x > 18 ) ) return;
	numpix = pix[num];
	ofs = fbofs + 116+(CHR_HEIGHT/2) + (8 + (18-x) * CHR_WIDTH)*240;

	for (y=5; y>0; y--, ofs -= 4) {
		ofs16 = ofs;
		for (i=3; i>0; i--, numpix >>= 1, ofs16 += 960) {
			c16 = (numpix & 1) ? (color & 0xffff) : 0;
			ofs16[0] = c16; ofs16[1] = c16; ofs16[2] = c16; ofs16[3] = c16;
			ofs16[240+0] = c16; ofs16[240+1] = c16; ofs16[240+2] = c16; ofs16[240+3] = c16;
			ofs16[240*2+0] = c16; ofs16[240*2+1] = c16; ofs16[240*2+2] = c16; ofs16[240*2+3] = c16;
			ofs16[240*3+0] = c16; ofs16[240*3+1] = c16; ofs16[240*3+2] = c16; ofs16[240*3+3] = c16;
		}
	}
}

//
//	Print Clock
//
void print_clock(void) {
	char		datestr[20];
	uint32_t	x, fx, fw, color, white, red;

	white = 0x0000FFFF; red = 0x0000F800;

	read_clock();
	sprintf(datestr, "%04u/%02u/%02u %02u:%02u:%02u",
		clk.tm_year+1900, clk.tm_mon+1, clk.tm_mday, clk.tm_hour, clk.tm_min, clk.tm_sec);
	fx = focus * 3 + ((focus != YEAR) ? 2 : 0);
	fw = (focus == YEAR) ? 4 : 2;
	for (x=0; x<19; x++) {
		color = ((x >= fx) && (x < fx+fw)) ? red : white;
		print_num(datestr[x], x, color);
	}
}

//
//	Update Clock thread
//
static void* update_clock_thread(void* param) {
	struct timeval tod;

	while(1) {
		pthread_mutex_lock(&clock_mx);
		print_clock();
		pthread_mutex_unlock(&clock_mx);
		gettimeofday(&tod, NULL);
		usleep(1000000 - tod.tv_usec);
	}
	return 0;
}

//
//	Get day max
//
int get_day_max(void) {
	int y;
	switch (clk.tm_mon + 1) {
		case 2:
			y = clk.tm_year + 1900;
			if ( ((y % 4 == 0) && (y % 100 != 0)) || (y % 400 == 0)) return 29;
			return 28;
		case 4:
		case 6:
		case 9:
		case 11:
			return 30;
		default:
			return 31;
	}
}

//
//	Set Clock
//
void set_clock_focus(int add) {
	static int	*cofs[6] = { &clk.tm_year, &clk.tm_mon, &clk.tm_mday, &clk.tm_hour, &clk.tm_min, &clk.tm_sec };
	const int	cmin[6] = {  70,  0,  1,  0,  0,  0 };
	const int	cmax[6] = { 137, 11, 31, 23, 59, 59 };
	int		*ofs = cofs[focus];
	int		min = cmin[focus];
	int		max = cmax[focus];

	pthread_mutex_lock(&clock_mx);
	if (focus == DAY) max = get_day_max();
	*ofs += add;
	while (*ofs < min) *ofs += (max - min + 1);
	while (*ofs > max) *ofs -= (max - min + 1);
	if ( ((focus == YEAR) || (focus == MON)) && (clk.tm_mday > 28) ) {
		max = get_day_max();
		if (clk.tm_mday > max) clk.tm_mday = max;
	}
	write_clock();
	pthread_mutex_unlock(&clock_mx);
}

//
//	Clock Adjuster main
//
int main() {
	int				input_fd;
	struct	input_event		ev;
	int				fd_fb;
	struct	fb_fix_screeninfo	finfo;
	struct	fb_var_screeninfo	vinfo;
	uint32_t			i, finish;
	uint8_t				*fb_addr;
	uint16_t			*ofs;

	// Initialize
	init_clock();

	// Prepare for button input
	input_fd = open("/dev/input/event0", O_RDWR);

	// Open FB
	fd_fb = open("/dev/fb0", O_RDWR);
	ioctl(fd_fb, FBIOGET_FSCREENINFO, &finfo);
	ioctl(fd_fb, FBIOGET_VSCREENINFO, &vinfo);
	ioctl(fd_fb, FBIOPUT_VSCREENINFO, &vinfo);
	fb_addr = mmap(0, finfo.smem_len, PROT_READ | PROT_WRITE, MAP_SHARED, fd_fb, 0);
	fbofs = (uint16_t*)fb_addr;

	// Clear FB (gray)
	for(i=320*240*2; i>0; i--) {
			//   RRRRRGGGGGGBBBBB
		*fbofs++ = 0b0010000100000100;
	}

	// Get currently displayed screen offset
	fbofs = (uint16_t*)fb_addr;
	fbofs += vinfo.yoffset * 240;

	// Clear Clock's background
	ofs = fbofs + (120 - DISPLAY_HEIGHT/2) + (160 - DISPLAY_WIDTH/2)*240;
	for(i=DISPLAY_WIDTH; i>0; i--) {
		memset(ofs, 0, DISPLAY_HEIGHT*2);
		ofs += 240;
	}

	// Start updating clock
	clock_mx = (pthread_mutex_t)PTHREAD_MUTEX_INITIALIZER;
	pthread_create(&clock_pt, NULL, update_clock_thread, NULL);

	// Adjust clock
	finish = 0;
	do {
		if ( read(input_fd, &ev, sizeof(ev)) != sizeof(ev) ) break;
		if ( (ev.type != EV_KEY) || (ev.value > REPEAT) ) continue;
		if ( ev.value != RELEASED ) {
			switch (ev.code) {
				case BUTTON_LEFT:
				case BUTTON_L:
					focus = (focus != YEAR) ? focus-1 : SEC;
					break;
				case BUTTON_RIGHT:
				case BUTTON_R:
					focus = (focus != SEC) ? focus+1 : YEAR;
					break;
				case BUTTON_UP:
					set_clock_focus(-1);
					break;
				case BUTTON_DOWN:
					set_clock_focus(+1);
					break;
				default:
					continue;
			}
			pthread_mutex_lock(&clock_mx);
			print_clock();
			pthread_mutex_unlock(&clock_mx);
		} else {
			switch (ev.code) {
				case BUTTON_A:
				case BUTTON_B:
				case BUTTON_X:
				case BUTTON_Y:
				case BUTTON_SELECT:
				case BUTTON_MENU:
				case BUTTON_START:
					finish = 1;
					break;
				default:
					break;
			}
		}
	} while(!finish);

	close(input_fd);

	// Stop updating clock
	pthread_cancel(clock_pt);
	pthread_join(clock_pt, NULL);

	// Close FB
	memset(fb_addr, 0, finfo.smem_len);
	munmap(fb_addr, finfo.smem_len);
	close(fd_fb);

	// update clock.txt
	read_clock();
	write_clock_rtc();
	write_clockfile();

	return 0;
}
