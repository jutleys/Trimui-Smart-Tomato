#include <stdio.h>
#include <unistd.h>
#include <stdint.h>
#include <SDL/SDL.h>
#include <SDL/SDL_ttf.h>

//	320x240 -> 240x320 rotate90 CCW
//	AB    BD
//	CD -> AC
void rotate320x240_rw32(void* __restrict src, void* __restrict dst) {
	uint32_t	*s, *d, pix1, pix2;
	int		x, y;

	s = (uint32_t*)src + 159;
	d = (uint32_t*)dst;
	for (x=160; x>0; x--, s -= 160*240+1, d += 120) {
		for (y=120; y>0; y--, s += 320, d++) {
			pix1 = s[0];					// read AB
			pix2 = s[160];					// read CD
			d[0] = (pix1>>16) | (pix2 & 0xFFFF0000);	// write BD
			d[120] = (pix1 & 0xFFFF) | (pix2<<16);		// write AC
		}
	}
}

//
//	PrintStr Main
//
int main(int argc, char* argv[]) {
	TTF_Font	*font;
	SDL_Color	color={255,155,58,0};
	SDL_Surface	*video, *screen, *screen_tmp, *image;
	SDL_Rect	rect;
	int16_t		height, center_y;

	if (argc == 2) {
		SDL_Init(SDL_INIT_VIDEO);
		setenv("SDL_USE_PAN", "true", 1);					// allow DOUBLEBUF
		video = SDL_SetVideoMode(240, 320, 16, SDL_HWSURFACE | SDL_DOUBLEBUF);	// rotated LCD

		// Clear Screen
		SDL_FillRect(video, NULL, 0);
		SDL_Flip(video);
		SDL_FillRect(video, NULL, 0);
		SDL_Flip(video);

		TTF_Init();
		font = TTF_OpenFont("/usr/trimui/res/OPPOSans-B-2.ttf", 24);
		image = TTF_RenderUTF8_Blended(font, argv[1], color);
		TTF_CloseFont(font);
		TTF_Quit();

		height = image->w * 3 / 4;
		center_y = (height-image->h)/2;
		rect.x = 0;
		rect.y = center_y;
		rect.w = (uint16_t)image->w;
		rect.h = (uint16_t)(center_y + image->h);

		screen_tmp = SDL_CreateRGBSurface(0, image->w, height, 16, 0xF800, 0x7E0, 0x1F, 0);
		SDL_BlitSurface(image, NULL, screen_tmp, &rect);
		SDL_FreeSurface(image);

		screen = SDL_CreateRGBSurface(0, 320, 240, 16, 0xF800, 0x7E0, 0x1F, 0);
		SDL_SoftStretch(screen_tmp, NULL, screen, NULL);
		SDL_FreeSurface(screen_tmp);

		// Draw 2 screens
		rotate320x240_rw32(screen->pixels, video->pixels);
		SDL_Flip(video);
		rotate320x240_rw32(screen->pixels, video->pixels);
		SDL_Flip(video);

		// Quit
		SDL_FreeSurface(screen);
		SDL_Quit();
	}
	return 0;
}
