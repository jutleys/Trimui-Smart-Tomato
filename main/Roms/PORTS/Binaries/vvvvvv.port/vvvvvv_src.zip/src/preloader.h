#ifndef PRELOADER_H
#define PRELOADER_H

#include "Graphics.h"
#include "Game.h"
#include "UtilityClass.h"

void preloaderrender(Graphics& dwgfx, Game& game, UtilityClass& help);

#endif /* PRELOADER_H */
