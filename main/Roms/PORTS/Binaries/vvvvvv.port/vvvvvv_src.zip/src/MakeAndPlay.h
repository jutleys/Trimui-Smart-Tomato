#ifndef MAKEANDPLAY_H
#define MAKEANDPLAY_H

/* This is a cheap way to deal with the MAKEANDPLAY def when recompiling.
 * It's heaps faster than rebuilding everything, so here we are.
 * -flibit
 */
// #define MAKEANDPLAY

#endif /* MAKEANDPLAY_H */
