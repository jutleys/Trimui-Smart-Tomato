#include "Screen.h"

#include "FileSystemUtils.h"
#include "GraphicsUtil.h"
#include "TMSr90.h"

#include <stdlib.h>

Screen::Screen()
{
    m_screen = NULL;
    isWindowed = true;
    stretchMode = 0;
    isFiltered = false;
    filterSubrect.x = 1;
    filterSubrect.y = 1;
    filterSubrect.w = 318;
    filterSubrect.h = 238;

	// TMSr90 fast mode
	a_screen = TMS_SetVideoMode(320, 240, 16, SDL_HWSURFACE);
	m_screen = SDL_CreateRGBSurface(SDL_SWSURFACE, 320, 240, 32,
	0x00FF0000,
	0x0000FF00,
	0x000000FF,
	0xFF000000);

    badSignalEffect = false;

    glScreen = true;
}

void Screen::ResizeScreen(int x , int y) {}

void Screen::GetWindowSize(int* x, int* y) {}

void Screen::UpdateScreen(SDL_Surface* buffer, SDL_Rect* rect )
{
    if((buffer == NULL) && (m_screen == NULL) )
    {
        return;
    }

    if(badSignalEffect)
    {
        buffer = ApplyFilter(buffer);
    }

    SDL_FillRect(m_screen, NULL, 0);
    BlitSurfaceStandard(buffer, NULL, m_screen, rect);

    if(badSignalEffect)
    {
        SDL_FreeSurface(buffer);
    }
    //SDL_Flip(screen);
}

const SDL_PixelFormat* Screen::GetFormat()
{
    return m_screen->format;
}

void Screen::FlipScreen()
{
//	convert 32->16bpp
	Uint32 *src = (Uint32 *)m_screen->pixels;
	Uint32 *dst = (Uint32 *)a_screen->pixels;
	Uint32 a,b;
	for (Uint32 i=0;i<320*240/2;i++) {
		a = *src++; b = *src++;
		*dst++ =(a&0x00F80000)>>8  |	//R1
			(a&0x0000FC00)>>5  |	//G1
			(a&0x000000F8)>>3  |	//B1
			(b&0x00F80000)<<8  |	//R2
			(b&0x0000FC00)<<11 |	//G2
			(b&0x000000F8)<<13;	//B2
	}

	TMS_Flip(a_screen);
//	SDL_FillRect(m_screen, NULL, 0);
}

void Screen::toggleFullScreen()
{
	isWindowed = !isWindowed;
	ResizeScreen(-1, -1);
}

void Screen::toggleStretchMode()
{
	stretchMode = (stretchMode + 1) % 3;
	ResizeScreen(-1, -1);
}

void Screen::toggleLinearFilter() {
	isFiltered = !isFiltered;
}

void Screen::ClearScreen( int colour )
{
	FillRect(m_screen, colour) ;
}
