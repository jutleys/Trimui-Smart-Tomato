#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <dirent.h>
#include <fcntl.h>
#include <stdint.h>
#include <string.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <linux/fb.h>
#include <linux/input.h>
#include <png.h>

//
//	Get Most recent file name from Roms/recentlist.json
//
char* getrecent(char *filename) {
	FILE		*fp;
	char		*fnptr;
	uint32_t	i;

	strcpy(filename, "/mnt/SDCARD/Screenshots/");
	if (access(filename, F_OK)) mkdir(filename, 777);

	fnptr = filename + strlen(filename);

	if (!access("/tmp/cmd_to_run.sh", F_OK)) {
		// for stock
		if ((fp = fopen("/mnt/SDCARD/Roms/recentlist.json", "r"))) {
			fscanf(fp, "%*255[^:]%*[:]%*[\"]%255[^\"]", fnptr);
			fclose(fp);
		}
	}

	if (!(*fnptr)) strcat(filename, "MainUI");

	fnptr = filename + strlen(filename);
	for (i=0; i<1000; i++) {
		sprintf(fnptr, "_%03d.png", i);
		if ( access(filename, F_OK) != 0 ) break;
	} if (i > 999) return NULL;
	return filename;
}

//	Reverse LED color
void reverseLEDcolor(void) {
//			   01234567890123456789012345678901234567890 = 40
	char	ledfn[] = "/sys/devices/platform/sunxi-led/leds/led#/brightness";
	char	ledonoff[2][4] = { "255", "0" };
	char	readbuf[4];
	uint32_t	i, sz, ledstatus;
	int	fd;

	for (i=3; i>0; i--) {
		ledfn[40] = i + 0x30;
		fd = open(ledfn, O_RDONLY);
		if (fd>=0) {
			sz = read(fd, readbuf, 4);
			close(fd);
			printf("sz:%d str:%s", sz, readbuf);
			if ((readbuf[0] == '0')&&(sz == 2)) ledstatus = 0;
			else ledstatus = 1;
			fd = open(ledfn, O_WRONLY);
			if (fd>=0) {
				dprintf(fd, ledonoff[ledstatus]);
				close(fd);
			}
		}
	}
}

//
//	Screenshot (320x240, rotate90, png)
//
void screenshot(void) {
	char		screenshotname[512];
	uint32_t	x, y, linebuffer[320];
	uint16_t	*buffer, *src, pix;
	FILE		*fp;
	int		fd_fb;
	struct		fb_var_screeninfo vinfo;
	png_structp	png_ptr;
	png_infop	info_ptr;

	if (getrecent(screenshotname) == NULL) return;
	if ((buffer = (uint16_t*)malloc(240*320*2)) != NULL) {
		fd_fb = open("/dev/fb0", O_RDWR);
		ioctl(fd_fb, FBIOGET_VSCREENINFO, &vinfo);
		lseek(fd_fb, 240*vinfo.yoffset*2, SEEK_SET);
		read(fd_fb, buffer, 240*320*2);
		close(fd_fb);

		fp = fopen(screenshotname, "wb");
		if (fp != NULL) {
			png_ptr = png_create_write_struct(PNG_LIBPNG_VER_STRING, 0, 0, 0);
			info_ptr = png_create_info_struct(png_ptr);
			png_init_io(png_ptr, fp);
			png_set_IHDR(png_ptr, info_ptr, 320, 240, 8, PNG_COLOR_TYPE_RGBA,
				PNG_INTERLACE_NONE, PNG_COMPRESSION_TYPE_DEFAULT, PNG_FILTER_TYPE_DEFAULT);
			png_write_info(png_ptr, info_ptr);
			src = buffer + (240*319);
			for (y=0; y<240; y++, src += 240*320+1) {
				for (x=0; x<320; x++, src -= 240){
					pix = *src;
					linebuffer[x] = 0xFF000000 |
							(pix & 0xF100)>>8 | (pix & 0xE000)>>13 |
							(pix & 0x07E0)<<5 | (pix & 0x0600)>>1 |
							(pix & 0x001F)<<19 | (pix & 0x001C)<<14 ;
				}
				png_write_row(png_ptr, (png_bytep)linebuffer);
				if (!(y&0x3F)) reverseLEDcolor();
			}
			png_write_end(png_ptr, info_ptr);
			png_destroy_write_struct(&png_ptr, &info_ptr);
			fclose(fp);
			sync();
		}
		free(buffer);
	}
}

//
//	Screenshot Sample Main
//
#define	BUTTON_MENU	KEY_ESC
#define	BUTTON_L2	KEY_TAB
#define	BUTTON_R2	KEY_BACKSPACE
int main() {
	int			input_fd;
	struct input_event	ev;
	uint32_t		val, l2_pressed, r2_pressed, menu_pressed;

	// Prepare for Poll button input
	input_fd = open("/dev/input/event0", O_RDONLY);

	l2_pressed = r2_pressed = menu_pressed = 0;
	while( read(input_fd, &ev, sizeof(ev)) == sizeof(ev) ) {
		val = ev.value;
		if (( ev.type != EV_KEY ) || ( val > 1 )) continue;
		if (( ev.code == BUTTON_L2 )||( ev.code == BUTTON_R2 )||( ev.code == BUTTON_MENU )) {
			if ( ev.code == BUTTON_L2 ) {
				l2_pressed = val;
			} else if ( ev.code == BUTTON_R2 ) {
				r2_pressed = val;
			} else	menu_pressed = val;
			if (l2_pressed & r2_pressed & menu_pressed) {
				screenshot();
				l2_pressed = r2_pressed = menu_pressed = 0;
			}
		}
	}

	// Quit
	close(input_fd);

	return 0;
}
