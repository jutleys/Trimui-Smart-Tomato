#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <stdint.h>
#include <string.h>
#include <dirent.h>
#include <fcntl.h>
#include <pthread.h>
#include <poll.h>
#include <signal.h>
#include <time.h>
#include <sys/mman.h>
#include <sys/stat.h>
#include <linux/fb.h>
#include <linux/input.h>
#include <linux/rtc.h>
#include <png.h>

//	Button Defines
#define BUTTON_UP	KEY_UP
#define BUTTON_DOWN	KEY_DOWN
#define BUTTON_LEFT	KEY_LEFT
#define BUTTON_RIGHT	KEY_RIGHT
#define BUTTON_A	KEY_SPACE
#define BUTTON_B	KEY_LEFTCTRL
#define BUTTON_X	KEY_LEFTSHIFT
#define BUTTON_Y	KEY_LEFTALT
#define	BUTTON_L	KEY_TAB
#define	BUTTON_R	KEY_BACKSPACE
#define	BUTTON_SELECT	KEY_RIGHTCTRL
#define	BUTTON_START	KEY_ENTER
#define	BUTTON_MENU	KEY_ESC

//	for ev.value
#define RELEASED	0
#define PRESSED		1
#define REPEAT		2

//	for proc_stat flags
#define PF_KTHREAD	0x00200000

//	long press time for MENU (ms)
#define	REPEAT_TIME	2000

//	for clock
#define	CHR_WIDTH	(3 * 2 + 2)
#define	CHR_HEIGHT	(5 * 2)
#define	DISPLAY_WIDTH	(CHR_WIDTH * 19)
#define	DISPLAY_HEIGHT	(CHR_HEIGHT + 2)
enum { YEAR, MON, DAY, HOUR, MIN, SEC };

//	Global Variables
#define			PIDMAX	32
uint32_t		suspendpid[PIDMAX];
int			input_fd;
struct	input_event	ev;
struct	tm		clk;
pthread_t		clock_pt;
pthread_mutex_t		clock_mx;
uint8_t			*fbofs;
uint32_t		focus = HOUR;

//
//	Suspend
//
void suspend(void) {
	DIR *procdp;
	struct dirent *dir;
	char fname[32];
	pid_t suspend_pid = getpid();
	pid_t pid;
	pid_t ppid;
	char state;
	uint32_t flags;
	char comm[128];

	procdp = opendir("/proc");

	// Pick active processes to suspend and send SIGSTOP
	// Cond:1. PID is greater than 2(kthreadd) and not myself
	//	2. PPID is greater than 2(kthreadd)
	//	3. state is "R" or "S" or "D"
	//	4. comm is not "(sh)" ( and "(keymon)" if needed )
	//	5. flags does not contain PF_KTHREAD (0x200000)
	suspendpid[0] = 0;
	while ((dir = readdir(procdp))) {
		if (dir->d_type == DT_DIR) {
			pid = atoi(dir->d_name);
			if (( pid > 2 )&&( pid != suspend_pid )) {
				sprintf(fname, "/proc/%d/stat", pid);
				FILE *fp = fopen(fname, "r");
				if (fp) {
					fscanf(fp, "%*d %127s %c %d %*d %*d %*d %*d %u", (char*)&comm, &state, &ppid, &flags);
					fclose(fp);
				}
				//fprintf(stderr, "pid: %d ppid:%d mainpid:%d state:%c flags:%x comm:%s\n",pid,ppid,main_pid,state,flags,comm);
				if ( (ppid > 2) && ((state == 'R')||(state == 'S')||(state == 'D')) &&
				     (strcmp(comm,"(sh)")) && /* (strcmp(comm,"(keymon)")) && */ (!(flags & PF_KTHREAD)) ) {
					if ( suspendpid[0] < PIDMAX ) {
						suspendpid[++suspendpid[0]] = pid;
						kill(pid,SIGSTOP);
					}
				}
			}
		}
	}
	closedir(procdp);
}

//
//	Resume
//
void resume(void) {
	// Send SIGCONT to suspended processes
	if (suspendpid[0]) {
		for (uint32_t i=1; i <= suspendpid[0]; i++) {
			kill(suspendpid[i], SIGCONT);
		}
	}
}

//
//	Get Most recent file name from Roms/recentlist.json
//
char* getrecent(char *filename) {
	FILE		*fp;
	char		*fnptr;
	uint32_t	i;

	strcpy(filename, "/mnt/SDCARD/Screenshots/");
	if (access(filename, F_OK)) mkdir(filename, 777);

	fnptr = filename + strlen(filename);

	if (!access("/tmp/cmd_to_run.sh", F_OK)) {
		// for stock
		if ((fp = fopen("/mnt/SDCARD/Roms/recentlist.json", "r"))) {
			fscanf(fp, "%*255[^:]%*[:]%*[\"]%255[^\"]", fnptr);
			fclose(fp);
		}
	}

	if (!(*fnptr)) strcat(filename, "MainUI");

	fnptr = filename + strlen(filename);
	for (i=0; i<1000; i++) {
		sprintf(fnptr, "_%03d.png", i);
		if ( access(filename, F_OK) != 0 ) break;
	} if (i > 999) return NULL;
	return filename;
}

//
//	Reverse LED color
//
void reverseLEDcolor(void) {
//			   01234567890123456789012345678901234567890 = 40
	char	ledfn[] = "/sys/devices/platform/sunxi-led/leds/led#/brightness";
	char	ledonoff[2][4] = { "255", "0" };
	char	readbuf[4];
	uint32_t	i, sz, ledstatus;
	int	fd;

	for (i=3; i>0; i--) {
		ledfn[40] = i + 0x30;
		fd = open(ledfn, O_RDONLY);
		if (fd>=0) {
			sz = read(fd, readbuf, 4);
			close(fd);
			printf("sz:%d str:%s", sz, readbuf);
			if ((readbuf[0] == '0')&&(sz == 2)) ledstatus = 0;
			else ledstatus = 1;
			fd = open(ledfn, O_WRONLY);
			if (fd>=0) {
				dprintf(fd, ledonoff[ledstatus]);
				close(fd);
			}
		}
	}
}

//
//	Screenshot (320x240, rotate90, png)
//
void screenshot(void) {
	char		screenshotname[512];
	uint32_t	x, y, linebuffer[320];
	uint16_t	*buffer = (uint16_t*)fbofs;
	uint16_t	*src, pix;
	FILE		*fp;
	png_structp	png_ptr;
	png_infop	info_ptr;

	if (getrecent(screenshotname) == NULL) return;

	fp = fopen(screenshotname, "wb");
	if (fp != NULL) {
		png_ptr = png_create_write_struct(PNG_LIBPNG_VER_STRING, 0, 0, 0);
		info_ptr = png_create_info_struct(png_ptr);
		png_init_io(png_ptr, fp);
		png_set_IHDR(png_ptr, info_ptr, 320, 240, 8, PNG_COLOR_TYPE_RGBA,
			PNG_INTERLACE_NONE, PNG_COMPRESSION_TYPE_DEFAULT, PNG_FILTER_TYPE_DEFAULT);
		png_write_info(png_ptr, info_ptr);
		src = buffer + (240*319);
		for (y=0; y<240; y++, src += 240*320+1) {
			for (x=0; x<320; x++, src -= 240){
				pix = *src;
				linebuffer[x] = 0xFF000000 |
						(pix & 0xF100)>>8 | (pix & 0xE000)>>13 |
						(pix & 0x07E0)<<5 | (pix & 0x0600)>>1 |
						(pix & 0x001F)<<19 | (pix & 0x001C)<<14 ;
			}
			png_write_row(png_ptr, (png_bytep)linebuffer);
			if (!(y&0x3F)) reverseLEDcolor();
		}
		png_write_end(png_ptr, info_ptr);
		png_destroy_write_struct(&png_ptr, &info_ptr);
		fclose(fp);
		sync();
	}
}

//
//	Read Clock (system)
//
void read_clock(void) {
	struct timeval tod;
	gettimeofday(&tod, NULL);
	gmtime_r(&tod.tv_sec, &clk);
}

//
//	Read Clock (RTC)
//
void read_clock_rtc(void) {
	int cfd = open("/dev/rtc0", O_RDONLY);
	if (cfd > 0) {
		ioctl(cfd, RTC_RD_TIME, &clk);
		close(cfd);
	} else	read_clock();
}

//
//	Write Clock (system)
//
void write_clock(void) {
	struct timeval tod;
	gettimeofday(&tod, NULL);
	tod.tv_sec = mktime(&clk);
	settimeofday(&tod, NULL);
}

//
//	Write Clock (RTC & system)
//
void write_clock_rtc(void) {
	int cfd = open("/dev/rtc0", O_WRONLY);
	if (cfd > 0) { ioctl(cfd, RTC_SET_TIME, &clk); close(cfd); }
	write_clock();
}

//
//	Initialize Clock
//
void init_clock(void) {
	read_clock();
	write_clock_rtc();
	FILE* fp = fopen("clockd.txt", "r");
	if (fp) {
		time_t now = mktime(&clk);
		fscanf(fp, "%04u/%02u/%02u %02u:%02u:%02u",
			&clk.tm_year, &clk.tm_mon, &clk.tm_mday, &clk.tm_hour, &clk.tm_min, &clk.tm_sec);
		fclose(fp);
		clk.tm_year -= 1900; clk.tm_mon--;
		if ( now < mktime(&clk) ) write_clock_rtc();
	}
}

//
//	Write clockd.txt
//
void write_clockfile(void) {
	FILE* fp = fopen("clockd.txt", "w");
	if (fp) {
		fprintf(fp, "%04u/%02u/%02u %02u:%02u:%02u",
			clk.tm_year+1900, clk.tm_mon+1, clk.tm_mday, clk.tm_hour, clk.tm_min, clk.tm_sec);
		fflush(fp);
		fsync(fileno(fp));
		fclose(fp);
	}
}

//
//	Quit
//
void quit(int exitcode) {
	if (input_fd > 0) close(input_fd);
	read_clock();
	write_clock_rtc();
	write_clockfile();
	exit(exitcode);
}

//
//	Print Number (rotate90 240x320 upper_right corner)
//
void print_num(uint8_t num, uint32_t x, uint32_t color) {
	const uint16_t pix[13] = {
		0b000000000000000,	// space
		0b000001010100000,	// /
		0b111101101101111,	// 0
		0b001001001001001,	// 1
		0b111001111100111,	// 2
		0b111001111001111,	// 3
		0b101101111001001,	// 4
		0b111100111001111,	// 5
		0b111100111101111,	// 6
		0b111001001001001,	// 7
		0b111101111101111,	// 8
		0b111101111001111,	// 9
		0b000010000010000 };	// :
	uint32_t	i, y;
	uint16_t	numpix, c16;
	uint8_t		*ofs;
	uint16_t	*ofs16;

	if ( num == ' ' ) num = 0; else num -= 0x2e;
	if ( ( num > 12 ) || ( x > 18 ) ) return;
	numpix = pix[num];
	ofs = fbofs + 238*2 + ((18-x) * CHR_WIDTH * 2)*240;

	for (y=5; y>0; y--, ofs-=4) {
		ofs16 = (uint16_t*)ofs;
		for (i=3; i>0; i--, numpix >>= 1, ofs16 += 480) {
			c16 = (numpix & 1) ? (color & 0xffff) : 0;
			ofs16[0] = c16; ofs16[1] = c16;
			ofs16[240] = c16; ofs16[241] = c16;
		}
	}
}

//
//	Print Clock
//
void print_clock(void) {
	char		datestr[20];
	uint32_t	x, fx, fw, color, white, red;

	white = 0x0000FFFF; red = 0x0000F800;

	read_clock();
	sprintf(datestr, "%04u/%02u/%02u %02u:%02u:%02u",
		clk.tm_year+1900, clk.tm_mon+1, clk.tm_mday, clk.tm_hour, clk.tm_min, clk.tm_sec);
	fx = focus * 3 + ((focus != YEAR) ? 2 : 0);
	fw = (focus == YEAR) ? 4 : 2;
	for (x=0; x<19; x++) {
		color = ((x >= fx) && (x < fx+fw)) ? red : white;
		print_num(datestr[x], x, color);
	}
}

//
//	Update Clock thread
//
static void* update_clock_thread(void* param) {
	struct timeval tod;

	while(1) {
		pthread_mutex_lock(&clock_mx);
		print_clock();
		pthread_mutex_unlock(&clock_mx);
		gettimeofday(&tod, NULL);
		usleep(1000000 - tod.tv_usec);
	}
	return 0;
}

//
//	Get day max
//
int get_day_max(void) {
	int y;
	switch (clk.tm_mon + 1) {
		case 2:
			y = clk.tm_year + 1900;
			if ( ((y % 4 == 0) && (y % 100 != 0)) || (y % 400 == 0)) return 29;
			return 28;
		case 4:
		case 6:
		case 9:
		case 11:
			return 30;
		default:
			return 31;
	}
}

//
//	Set Clock
//
void set_clock_focus(int add) {
	static int	*cofs[6] = { &clk.tm_year, &clk.tm_mon, &clk.tm_mday, &clk.tm_hour, &clk.tm_min, &clk.tm_sec };
	const int	cmin[6] = {  70,  0,  1,  0,  0,  0 };
	const int	cmax[6] = { 137, 11, 31, 23, 59, 59 };
	int		*ofs = cofs[focus];
	int		min = cmin[focus];
	int		max = cmax[focus];

	pthread_mutex_lock(&clock_mx);
	if (focus == DAY) max = get_day_max();
	*ofs += add;
	while (*ofs < min) *ofs += (max - min + 1);
	while (*ofs > max) *ofs -= (max - min + 1);
	if ( ((focus == YEAR) || (focus == MON)) && (clk.tm_mday > 28) ) {
		max = get_day_max();
		if (clk.tm_mday > max) clk.tm_mday = max;
	}
	write_clock();
	pthread_mutex_unlock(&clock_mx);
}

//
//	Adjust Clock interface
//
void adjust_clock(void) {
	int				fd_fb;
	struct	fb_fix_screeninfo	finfo;
	struct	fb_var_screeninfo	vinfo;
	uint32_t			i, ofss, ofsd, finish;
	uint8_t				*fb_addr, *savebuf;

	// Open FB
	fd_fb = open("/dev/fb0", O_RDWR);
	ioctl(fd_fb, FBIOGET_FSCREENINFO, &finfo);
	ioctl(fd_fb, FBIOGET_VSCREENINFO, &vinfo);
	ioctl(fd_fb, FBIOPUT_VSCREENINFO, &vinfo);
	fb_addr = mmap(0, finfo.smem_len, PROT_READ | PROT_WRITE, MAP_SHARED, fd_fb, 0);

	fbofs = fb_addr + ( vinfo.yoffset * 480 );

	// Save display area and clear (rotate90)
	savebuf = malloc(DISPLAY_HEIGHT * 2 * DISPLAY_WIDTH);
	ofss = 480 - (DISPLAY_HEIGHT * 2); ofsd = 0;
	for (i=DISPLAY_WIDTH; i>0; i--, ofss += 480, ofsd += DISPLAY_HEIGHT * 2) {
		memcpy(savebuf + ofsd, fbofs + ofss, DISPLAY_HEIGHT * 2);
		memset(fbofs + ofss, 0, DISPLAY_HEIGHT * 2);
	}

	// Start updating clock
	clock_mx = (pthread_mutex_t)PTHREAD_MUTEX_INITIALIZER;
	pthread_create(&clock_pt, NULL, update_clock_thread, NULL);

	// Wait until release MENU button
	do { if ( read(input_fd, &ev, sizeof(ev)) != sizeof(ev) ) break;
	} while ( (ev.type != EV_KEY) || (ev.code != BUTTON_MENU) || (ev.value != RELEASED) );

	// Adjust clock
	finish = 0;
	do {
		if ( read(input_fd, &ev, sizeof(ev)) != sizeof(ev) ) break;
		if ( (ev.type != EV_KEY) || (ev.value > REPEAT) ) continue;
		if ( ev.value != RELEASED ) {
			switch (ev.code) {
				case BUTTON_LEFT:
				case BUTTON_L:
					focus = (focus != YEAR) ? focus-1 : SEC;
					break;
				case BUTTON_RIGHT:
				case BUTTON_R:
					focus = (focus != SEC) ? focus+1 : YEAR;
					break;
				case BUTTON_UP:
					set_clock_focus(-1);
					break;
				case BUTTON_DOWN:
					set_clock_focus(+1);
					break;
				default:
					continue;
			}
			pthread_mutex_lock(&clock_mx);
			print_clock();
			pthread_mutex_unlock(&clock_mx);
		} else {
			switch (ev.code) {
				case BUTTON_A:
				case BUTTON_B:
				case BUTTON_X:
				case BUTTON_Y:
				case BUTTON_SELECT:
				case BUTTON_MENU:
					finish = 1;
					break;
				case BUTTON_START:
					screenshot();
					finish = 1;
					break;
				default:
					break;
			}
		}
	} while(!finish);

	// Stop updating clock
	pthread_cancel(clock_pt);
	pthread_join(clock_pt, NULL);

	// Restore display area
	ofss = 0; ofsd = 480 - (DISPLAY_HEIGHT * 2);
	for (i=DISPLAY_WIDTH; i>0; i--, ofss += DISPLAY_HEIGHT * 2, ofsd += 480) {
		memcpy(fbofs + ofsd, savebuf + ofss, DISPLAY_HEIGHT * 2);
	}

	// Close FB
	free(savebuf);
	munmap(fb_addr, finfo.smem_len);
	close(fd_fb);

	// update clockd.txt
	read_clock();
	write_clock_rtc();
	write_clockfile();
}

//
//	Clock daemon Main
//
int main() {
	// Initialize
	signal(SIGTERM, quit);
	signal(SIGINT,  quit);
	signal(SIGSEGV, quit);

	init_clock();

	// Prepare for button input
	input_fd = open("/dev/input/event0", O_RDWR);
	struct	pollfd	fds[1];
	memset(&fds, 0, sizeof(fds));
	fds[0].fd = input_fd;
	fds[0].events = POLLIN;
	uint32_t	menu_pressed;

	// recognize long press MENU to adjust clock
	while( read(input_fd, &ev, sizeof(ev)) == sizeof(ev) ) {
		if ( (ev.type != EV_KEY) || (ev.code != BUTTON_MENU) || (ev.value != PRESSED) ) continue;
		menu_pressed = 1;
		usleep(REPEAT_TIME * 1000);
		while ( poll(fds, 1, 0) > 0 ) {
			read(input_fd, &ev, sizeof(ev));
			if ( (ev.type == EV_KEY) && (ev.code == BUTTON_MENU) && (ev.value == RELEASED) ) {
				menu_pressed = 0; break;
			}
		}
		if (!menu_pressed) continue;

		// stop input event for other processes
		ioctl(input_fd, EVIOCGRAB, 1);
		// suspend
		suspend();

		// Adjust clock
		adjust_clock();

		// resume
		resume();
		// restart input event for other processes
		ioctl(input_fd, EVIOCGRAB, 0);
		// press&release MENU button to let other processes recognize
		ev.type = EV_KEY; ev.code = BUTTON_MENU; ev.value = PRESSED;
		write(input_fd, &ev, sizeof(ev));
		ev.value = RELEASED;
		write(input_fd, &ev, sizeof(ev));
	}
	// Quit
	quit(0);

	return 0;
}
